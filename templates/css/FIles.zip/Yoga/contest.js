flatpickr("#startDate", {
    dateFormat: "Y-m-d",
    minDate: "today",
});
flatpickr("#endDate", {
    dateFormat: "Y-m-d",
    minDate: "today",
});