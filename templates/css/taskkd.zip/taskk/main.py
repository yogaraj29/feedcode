from fastapi import FastAPI,Form, Request, Depends,File,UploadFile
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from database import SessionLocal  
from fastapi.staticfiles import StaticFiles
from datetime import datetime
import models as models
from fastapi.responses import RedirectResponse
from fastapi import FastAPI, Depends
from fastapi.encoders import jsonable_encoder
from typing import Dict,List, Union,Optional
import os
import shutil, base64, io, uuid, re
import uuid
import json




current_date_time=datetime.utcnow()
app = FastAPI()


templates = Jinja2Templates(directory='templates')





def get_db():
    db = None
    try:
        db = SessionLocal()
        yield db
    finally:
        db.close()
    
@app.get('/get_form')
def get_form(request: Request,db:Session=Depends(get_db)):
    return templates.TemplateResponse("add.html", context={"request": request})

@app.post('/post_data')
def post_data(request:Request,db:Session=Depends(get_db),name:str=Form(...),dob:str=Form(...),age:str=Form(...),gender:str=Form(...),role:str=Form(...),degree:List=Form(...),marks:List=Form(...),image:UploadFile=File(...)):
    status="ACTIVE"
    created_at=current_date_time
    updated_at=""
    print(name)
    Dg=[]
    mar=[]
    for i,j in zip(degree,marks):
        a=""
        b=""
        for k in range(0,len(i)):
            if i[k]==',':
                Dg.append(a)
                a=""
                continue
            a+=i[k]
        for l in range(0,len(j)):
            if j[l]==',':
                mar.append(b)
                b=""
                continue
            b+=j[l]
        Dg.append(a)
        mar.append(b)
    print(Dg,mar)
            
        
    
    #below code=> get a image as file and convert string  using uuid and store into databse and that image file store in separate folder
    file_type=image.content_type
    ext=file_type.split('/')[-1]
    image4=str(uuid.uuid4())+ '.' + str(ext)
    file_loc=f"templates/UploadFiles/{image4}"
    with open(file_loc,"wb+") as file_view:
      shutil.copyfileobj(image.file,file_view)
       
    find=db.query(models.Bdetails).filter(models.Bdetails.Name==name,models.Bdetails.Status==status).first()
    if find is None:
        body=models.Bdetails(Name=name,Dob=dob,Age=age,Gender=gender,Role=role,proimg=image4,Status="ACTIVE",created_at=created_at,updated_at=updated_at)
        db.add(body)
        db.commit()
        s=db.query(models.Bdetails).all()
        c=0
        for i in s:
           c+=1
        for i,j in zip(Dg,mar):
            body1=models.Qdetails(Degree=i,Marks=j,qid=c,Status="ACTIVE",created_at=created_at,updated_at=updated_at)
            db.add(body1)
            db.commit()
            
        error="Done"
        jc=jsonable_encoder(error)
        return JSONResponse(content=jc)
    else:
        error="Already this name Exist"
        jc=jsonable_encoder(error)
        return JSONResponse(content=jc)
        