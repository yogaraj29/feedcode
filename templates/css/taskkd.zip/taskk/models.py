from sqlalchemy.schema import Column
from sqlalchemy.types import String, Integer, Date, BLOB, BigInteger, DATETIME, ARRAY,JSON
from database import Base,db_engine

class Bdetails(Base):
    __tablename__ = "bdetails"
    
    id = Column(Integer, primary_key=True,index=True)
    proimg=Column(String(300))
    Name = Column(String(300))
    Dob = Column(String(300))
    Age = Column(String(100))
    Gender = Column(String(100))
    Role = Column(String(100))
    Status = Column(String(100))
    created_at=Column(DATETIME)
    updated_at=Column(DATETIME)

class   Qdetails(Base):
    __tablename__ = "qdetails"
    
    id=Column(Integer, primary_key=True,index=True)
    Degree=Column(String(100))
    Marks=Column(String(100))
    qid=Column(Integer)
    Status=Column(String(100))
    created_at=Column(DATETIME)
    updated_at=Column(DATETIME)

Base.metadata.create_all(bind=db_engine)