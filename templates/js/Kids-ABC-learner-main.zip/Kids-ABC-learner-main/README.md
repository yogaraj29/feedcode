# Android app in Java that helps kids learn ABC with colorful images. 
## Fun way of learning ABC 
### 1. Learning module 
### 2. Quiz Module
### 3. Summary
